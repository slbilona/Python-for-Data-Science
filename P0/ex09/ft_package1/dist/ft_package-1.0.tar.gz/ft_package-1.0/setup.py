from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='1.0',
    packages=find_packages(),
    description='Un package avec les fontion du P0',
    author='Selbonne Ilona',
    author_email='ilonaselbonne@hotmail.fr',
    install_requires=[],
    url='https://github.com/slbilona/Python-for-Data-Science/tree/main/P0',
)
